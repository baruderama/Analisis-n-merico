x = 536.78
truncar = trunc(x*10) / 10
cat("Valor: ", truncar, "Error: ", x - truncar,"\n")

